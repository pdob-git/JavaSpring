package pl.pdob.H2config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2configApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2configApplication.class, args);
	}

}
