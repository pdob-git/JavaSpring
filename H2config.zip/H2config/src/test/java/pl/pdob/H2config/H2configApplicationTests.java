package pl.pdob.H2config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2configApplicationTests {

	@Test
	void contextLoads() {
	}

}
