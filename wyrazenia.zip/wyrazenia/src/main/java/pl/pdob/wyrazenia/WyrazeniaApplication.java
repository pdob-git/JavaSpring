package pl.pdob.wyrazenia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WyrazeniaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WyrazeniaApplication.class, args);
	}

}
